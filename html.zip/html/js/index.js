$(function(){
    //estas son read 
  $("#btnenviar").click(function() {
      console.log($("p").text());
      console.log($("p.rojo").html());
      console.log($("#btnenviar").val());
  })
  //estos son los write
  $("#btncambiar").click(function() {
    $("p.rojo").text("este es el nuevo parrafo");
    $("p.rojo").html("<stron>este es en negrita</stron>");
    $("p:last").html(function (i,prevHTML) {
      return prevHTML + "agrega HTML";
   
    //});
  })
    $("#btncambiar").val("nuevo cambiar");

    $("#btncambiar").attr("class","azul");

    $("#btnenviar").attr({
      "class":"azul",
      "miAtributo":"miValor"
    })
    $("#btnenviar").attr("class",function (i,preValue){
      console.log("Clase anterior"+preValue);
      return "rojo";
    })

    var boton = $("<input>").val("nuevo boton").attr("type","button");
    $("#btncambiar").after(boton);
    })

  });