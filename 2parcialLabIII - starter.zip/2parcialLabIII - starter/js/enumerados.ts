namespace Clases{

   export enum tipoDepartamento{
        Simple,
        Duplex,
        Triplex
    }

}