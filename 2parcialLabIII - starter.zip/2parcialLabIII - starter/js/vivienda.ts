namespace Clases{

export abstract class Vivienda{
    private id:number;
    private metros:number;
    private num_habitaciones:number;
   

    constructor(id:number,metros:number, num_habitaciones:number){
        this.id = id;
        this.metros = metros;
        this.num_habitaciones = num_habitaciones;
        
    }    

    //generar getters y setters de vivienda


}

}