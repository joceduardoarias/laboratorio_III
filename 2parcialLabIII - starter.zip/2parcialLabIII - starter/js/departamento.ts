/// <reference path="vivienda.ts" />
/// <reference path="enumerados.ts" />

//en el namespace Clases, exportar la clase Departamento que herede de vivienda.
//Departamento contara con los atributos privados tipo, y piso.

//generar constructor.

//generar getters y setters

//queda comentada una funcion estatica llamada "parseDepartamento" que puede ser de utilidad en la solucion

/*
        public static parseDepartamento(departameto:any):Departamento{
            return new Departamento(departameto.id,departameto.metros,departameto.num_habitaciones,departameto.piso,departameto.tipo);
        }
    */

