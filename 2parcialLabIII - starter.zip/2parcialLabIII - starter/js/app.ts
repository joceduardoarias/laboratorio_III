/// <reference path="departamento.ts" />
/// <reference path="vivienda.ts" />
/// <reference path="enumerados.ts" />
$(function () {
    // localStorage.clear();
    cargarTipos();

    mostrarDepartamentos();

    $('#cmbFiltro').change(function () {
        filtrarDepartamentos(this.value);
    });

//agregar al evento change de los 4 checkbox(USANDO JQUERY), el manejador "mapearCampos"


});

function agregarDepartamento(): void {
    let id: number = Number($('#txtId').val());
    let tipo: Clases.tipoDepartamento = Number($('#selectTipo').val());
    //crear nuevo departamento(nuevoDepartamento) en base a los datos del DOM
    

    let DepartamentosString: string | null = localStorage.getItem("Departamentos");

    let DepartamentosArray: Clases.Departamento[] = DepartamentosString == null ? [] : JSON.parse(DepartamentosString);

    //agregar el nuevo departamento a DepartamentosArray

    //guardar DepartamentosArray en localStorage con el nombre "Departamentos"

    

    alert("Departamento guardado!!!");

    mostrarDepartamentos();

    limpiarCampos();
    //console.log(nuevaDepartamento.toJSON());
}

function limpiarCampos() {
    $('#txtMetros').val("");
    $('#txtId').val("");
    $('#txtNumeroHabitaciones').val("");
    $('#txtPiso').val("");
    $('#selectTipo').val(0);

    $('#txtId').focus();
}

function mostrarDepartamentos() {

    let DepartamentosString: string | null = localStorage.getItem("Departamentos");

    let DepartamentosJSON: Clases.Departamento[] = DepartamentosString == null ? [] : JSON.parse(DepartamentosString);

    let tabla: string = "<table class='table'><thead><tr><th>Id</th><th>Num Hab.</th><th>Metros</th><th>Tipo</th><th>Piso</th></tr>";


    let dep:Clases.Departamento;
    for (let i = 0; i < DepartamentosJSON.length; i++) {
        dep = Clases.Departamento.parseDepartamento(DepartamentosJSON[i]);
        tabla += `<tr><td>${dep.ID}</td><td>${dep.Num_habitaciones}</td><td>${dep.Metros}</td><td>${Clases.tipoDepartamento[dep.Tipo]}</td><td>${dep.Piso}</td></tr>`;

    }

    tabla += `</table>`;

    $('#divTabla').html(tabla);

}

function cargarTipos() {

    for (let i = 0; i < Object.keys(Clases.tipoDepartamento).length / 2; i++) {
        $("#cmbFiltro").append('<option value="' + i + '">' + Clases.tipoDepartamento[i] + '</option>');
    }

    for (let i = 0; i < Object.keys(Clases.tipoDepartamento).length / 2; i++) {
        $("#selectTipo").append('<option value="' + i + '">' + Clases.tipoDepartamento[i] + '</option>');
    }

}

function filtrarDepartamentos(tipo: number) {

    let departamentosFiltrados: Array<Clases.Departamento>;

    let DepartamentosString: string | null = localStorage.getItem("Departamentos");

    let DepartamentosJSON: Clases.Departamento[] = DepartamentosString == null ? [] : JSON.parse(DepartamentosString);

    let dep:Clases.Departamento;
    //en "departamentosFiltrados", aplicar el filtro por tipo.
    //AYUDA. Usar el siguiente codigo: Clases.tipoDepartamento[dep.Tipo] === Clases.tipoDepartamento[tipo]


    mostrarDepartamentosPorTipo(departamentosFiltrados);

}

function cleanStorage() {
    //limpiar local storage

    alert("LocalStorage Limpio");
}

function mostrarDepartamentosPorTipo(lista: Array<Clases.Departamento>) {


    let tabla: string = "<table class='table'><thead><tr><th>Id</th><th>Num Hab.</th><th>Metros</th><th>Tipo</th><th>Piso</th></tr>";

    if (lista.length == 0) {
        tabla += "<tr><td colspan='4'>No hay departamentos que mostrar</td></tr>";
    }
    else {

        let dep:Clases.Departamento;
        for (let i = 0; i < lista.length; i++) {
            dep = Clases.Departamento.parseDepartamento(lista[i]);
            tabla += `<tr><td>${dep.ID}</td><td>${dep.Num_habitaciones}</td><td>${dep.Metros}</td><td>${Clases.tipoDepartamento[dep.Tipo]}</td><td>${dep.Piso}</td></tr>`;

        }

    }

    tabla += `</table>`;

    $('#divTabla').html(tabla);

}

function calcularPromedio() {

    let promedio: number = 0;
    let totalMetros: number;
    let cantidad: number;

    let tipo: number = Number($('#cmbFiltro').val());



    let departamentosFiltrados: Array<Clases.Departamento>;

    let DepartamentosString: string | null = localStorage.getItem("Departamentos");

    let DepartamentosJSON: Clases.Departamento[] = DepartamentosString == null ? [] : JSON.parse(DepartamentosString);

    let dep: Clases.Departamento;
  //filtrar Departamentos por tipo

//calcular suma de metros


    console.log(totalMetros);

    cantidad = departamentosFiltrados.length;


    console.log(cantidad);

    if (cantidad != 0) {
        //calcular promedio

    }
//asignar promedio  al valor de txtPromedio, usando jQuery
    

}

function mapearCampos() {

        let chkId: boolean = (<HTMLInputElement> $('#chkId')[0]).checked;
        let chkNumHab: boolean = (<HTMLInputElement> $('#chkNumHab')[0]).checked;
        let chkMetros: boolean = (<HTMLInputElement> $('#chkMetros')[0]).checked;
        let chkPiso: boolean = (<HTMLInputElement> $('#chkPiso')[0]).checked;

        //console.log(chkId);
        
    
        let DepartamentosString: string | null = localStorage.getItem("Departamentos");
    
        let DepartamentosJSON: Clases.Departamento[] = DepartamentosString == null ? [] : JSON.parse(DepartamentosString);
    
        let tabla: string = "<table class='table'><thead><tr>";
//hacer la logica para crear la tabla en base a los valores de los checkbox
        
    
        $('#divTabla').html(tabla);
    
    }
    