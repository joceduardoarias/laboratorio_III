$(function(){
    //que se oculta a x tiempo
    $("p:last").hide(4000,function () {
        //que se muestre en x tiempo
        $("p:last").show(4000);
    });
    $("#btnenviar").toggle(4000,function () {
        $("#btnenviar").toggle(4000);
    })
    //evento
    $("#btnenviar").click(function () {
        $("#btnenviar").animate({
            height:"+=50px",
            with: '+=50px'
        },1000).animate({
            height:"-=50px",
            with: '-=50px'
        },1000)
    })
  });