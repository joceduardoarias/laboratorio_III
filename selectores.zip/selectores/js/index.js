$(Function(){
    //selecciono por id
    console.log("#btnEnviar"));
    //selecciono por tag
    console.log($("p"));
    //selecciono por clase
    console.log($("p.rojo"));
    //selecciono por pseudo clase
    console.log()
})