$(function(){
  
    var boton = $("<input>").val("nuevo boton").attr("type","button").addClass("azul").css("margin","100px");
    $("body").append(boton);
    
    $("btncambiar").click(function() {

          $("#btnenviar").toggleClass("azul");    
      })
  
  });