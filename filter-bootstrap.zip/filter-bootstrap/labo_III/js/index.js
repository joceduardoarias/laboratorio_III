
let selPiases;
let selCiudades;    
window.addEventListener('load',function(){
    selPiases = document.getElementById('selPaises');
    selCiudades = document.getElementById('selCiudades');

    //obtenerPaises(datos);
    cargarSelect(selPiases,obtenerPaises(datos));
    cargarSelect(selCiudades,obtenerCiudades(datos,selPiases.value));
    selPiases.addEventListener('change',(e)=>{
      
        cargarSelect(selCiudades,obtenerCiudades(datos,e.target.value));
    })
});
/*version larga
function obtenerPaises(array) {
    //funciom map para filtrar, devuelve un array. 
    let paises = array.map(function(element){
        return element.pais;
    })
}*/
function obtenerPaises(array) {
    //funciom map para filtrar, devuelve un array 
    return array.map(element=>element.pais)
    .unique()//me retorna un array de tres elementos(unicamente los tres paises)
    .sort();
    //console.log(paises);
}
/*
function obtenerCiudades(array,pais) {
    let ciudades = array.filter(function(element){
        return element.pais === pais;
    })
}*/
function obtenerCiudades(array,pais) {
     return array.filter(element=>element.pais ===pais)
    .map(element=>element.ciudad)
    .unique()
    .sort();
}
//recibe una referencia del elemento html que quiero manipular
function cargarSelect(sel,array) {
    sel.options.length = 0;
    array.forEach(element => {
        //se crea la etiqueta option
        let option = document.createElement('option');
        //se le agrela el atributo
        option.setAttribute('value',element);
        let texto = document.createTextNode(element);
        option.appendChild(texto);
        sel.appendChild(option);
    });
    
}

//devuelve un array con el elmento
Array.prototype.unique = function(){
    return [...new Set(this)];
}
function limpiarSelect(sel){
    while(sel.hasChaildNodes())
    {
        sel.remove(sel.firstElementChild);
    }
}