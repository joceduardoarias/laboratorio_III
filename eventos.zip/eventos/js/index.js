

  $(function(){
    //manejar evento click
  $("#btnEnviar").click(function() {
      alert("boton enviar");
  })

  $("p.rojo").hover(function() {
      console.log("hola");
      
  }),
  function () {
     console.log("chau"); 
  }
  $("p.rojo").on("click",function() {
      
  })
  $("p.rojo").on({
      "click":function () {
          console.log("hola");
      },
      "mouseenter":function () {
          console.log("mouseenter hola");
      },
      
  })
})